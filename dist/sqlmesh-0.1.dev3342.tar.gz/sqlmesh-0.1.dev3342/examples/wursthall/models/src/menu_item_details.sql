MODEL (
  name src.menu_item_details,
  kind SEED (
    path '$root/seeds/src/menu_item_details.csv',
  ),
  owner jen
)
