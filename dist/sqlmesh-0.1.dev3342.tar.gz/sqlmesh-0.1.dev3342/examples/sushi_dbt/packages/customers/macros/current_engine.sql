{% macro default__current_engine() %}default{% endmacro %}

{% macro duckdb__current_engine() %}duckdb{% endmacro %}
