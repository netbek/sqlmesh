SELECT
  12.248 AS col_a,
  'b' AS col_b
