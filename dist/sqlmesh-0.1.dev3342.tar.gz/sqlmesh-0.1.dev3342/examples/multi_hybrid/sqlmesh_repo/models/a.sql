MODEL (
  name sqlmesh_repo.a
);

SELECT
  col_a,
  col_b
FROM dbt_repo.e;
