SELECT
  *
FROM {{ ref("a") }}
