from web.server.main import create_app

app = create_app()
