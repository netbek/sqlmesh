"""Add table_format to the model top-level properties"""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
