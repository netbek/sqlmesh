"""Changes the SCD Type 2 columns from strings to columns."""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
